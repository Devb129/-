import * as echarts from '../../ec-canvas/echarts';
// var mbills=[];
const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

  var option = {
    title: {
      text: '每月餐费支出趋势',
      left: 'center'
    },
    color: ["#37A2DA", "#67E0E3", "#9FE6B8"],
    legend: {
      data: ['A', 'B', 'C'],
      top: 50,
      left: 'center',
      backgroundColor: 'yellow',
      z: 100
    },
    grid: {
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['06-01', '06-02', '06-03', '06-04', '06-05', '06-06', '06-07'],
      // show: false
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
      // show: false
    },
    series: [{
      name: 'A',
      type: 'line',
      smooth: true,
      data: [18, 26, 35, 20, 28, 30, 43]
    }]
  };

  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/monthlybills/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      onInit: initChart
    },
    mbills:30
  },
  onLoad:function(options){
    var that=this
    console.log(1)
    wx.request({
      url: "http://www.website.com/duqu.php",
      method: 'GET',
      header: {
        'Content-type': 'application/json'
      },
      // data: {
      // },(res)=>
      success: function(res){
        console.log(res.data)
        that.setData({ 
          mbills:res.data.sum
        })
      }

    })
  },

  onReady() {
  }
});
